const fileInput = document.getElementById("fileInput");
const uploadArea = document.getElementById("uploadArea");
const fileLibrary = document.getElementById("fileLibrary");
const searchInput = document.getElementById("searchInput");
const categoryFilter = document.getElementById("categoryFilter");
const sortOption = document.getElementById("sortOption");
const totalFiles = document.getElementById("totalFiles");
const totalDownloads = document.getElementById("totalDownloads");

let filesData = JSON.parse(localStorage.getItem("bharatFiles")) || [
  {
    name: "Sample Academic Notes.pdf",
    type: "pdf",
    size: 256,
    content: "",
    category: "Academic Notes",
    date: new Date(),
    downloads: 4,
  },
  {
    name: "Modern Indian History.epub",
    type: "epub",
    size: 320,
    content: "",
    category: "Non-Fiction",
    date: new Date(),
    downloads: 2,
  },
];

function updateStats() {
  totalFiles.textContent = filesData.length;
  totalDownloads.textContent = filesData.reduce((acc, f) => acc + f.downloads, 0);
}

function renderLibrary() {
  fileLibrary.innerHTML = "";
  let query = searchInput.value.toLowerCase();
  let category = categoryFilter.value;

  let filtered = filesData.filter(file =>
    (category === "all" || file.category === category) &&
    file.name.toLowerCase().includes(query)
  );

  if (sortOption.value === "title") {
    filtered.sort((a, b) => a.name.localeCompare(b.name));
  } else if (sortOption.value === "downloads") {
    filtered.sort((a, b) => b.downloads - a.downloads);
  } else {
    filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
  }

  filtered.forEach((file, index) => {
    const card = document.createElement("div");
    card.className = "file-card";
    card.innerHTML = `
      <div class="file-title">${file.name}</div>
      <div class="file-meta">${file.type.toUpperCase()} • ${file.size} KB • ${file.category} • ${new Date(file.date).toLocaleDateString()}</div>
      <div class="actions">
        <button onclick="previewFile(${index})"><i class="fas fa-eye"></i> Preview</button>
        <button onclick="downloadFile(${index})"><i class="fas fa-download"></i> Download</button>
      </div>
    `;
    fileLibrary.appendChild(card);
  });

  updateStats();
}

function handleFileUpload(files) {
  Array.from(files).forEach(file => {
    if (file.size > 300 * 1024 * 1024) {
      alert(`File "${file.name}" exceeds 300MB limit.`);
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const category = prompt("Enter category (e.g., Fiction, Academic Notes):", "Textbooks");
      filesData.push({
        name: file.name,
        type: file.name.split('.').pop(),
        size: Math.round(file.size / 1024),
        content: reader.result,
        category: category || "Uncategorized",
        date: new Date(),
        downloads: 0,
      });
      localStorage.setItem("bharatFiles", JSON.stringify(filesData));
      renderLibrary();
    };
    reader.readAsDataURL(file);
  });
}

function downloadFile(index) {
  const file = filesData[index];
  const a = document.createElement("a");
  a.href = file.content;
  a.download = file.name;
  a.click();
  filesData[index].downloads++;
  localStorage.setItem("bharatFiles", JSON.stringify(filesData));
  renderLibrary();
}

function previewFile(index) {
  const file = filesData[index];
  alert(`Previewing "${file.name}" - feature demo. In a real app, this opens embedded viewer.`);
}

uploadArea.addEventListener("click", () => fileInput.click());
uploadArea.addEventListener("dragover", e => {
  e.preventDefault();
  uploadArea.style.background = "#cbe9ff";
});
uploadArea.addEventListener("dragleave", () => {
  uploadArea.style.background = "#ebf8ff";
});
uploadArea.addEventListener("drop", e => {
  e.preventDefault();
  uploadArea.style.background = "#ebf8ff";
  handleFileUpload(e.dataTransfer.files);
});
fileInput.addEventListener("change", () => handleFileUpload(fileInput.files));
searchInput.addEventListener("input", renderLibrary);
categoryFilter.addEventListener("change", renderLibrary);
sortOption.addEventListener("change", renderLibrary);

renderLibrary();
